var auto = 0;
var agct = 0;
var nerai1 = 0; var nerai2 = 0; var nerai3 = 0;
var bg_on = "#ffa84c"; var bg_off = "#ababab";
var bb_on = "solid 3px #cca84c"; var bb_off = "solid 3px #cdcdcd";
var cl_on = "rgba(200, 120, 12, 1)"; var cl_off = "rgba(12, 12, 12, 1)";

function exitConf(opt) {
	$('#opt').val(opt);
	webiopi().callMacro("dataUpdate2", [opt,], callbackExitConf);
}

function callbackExitConf(macro, args, data) {
	$('#article1').fadeOut( 1000 );
	setTimeout(function(){
		$('#article2').css({'display':'block'});
	},2000);
	setTimeout(function(){
		$('#frm').submit();
	},2000);
}

function exitConf1(opt) {
	webiopi().callMacro("dataUpdate2", [opt,]);
	$('#article1').fadeOut( 3000 );
//	$('#article1').css({'display':'none'});
	$('#article2').css({'display':'block'});
	setTimeout(function(){
		$('#opt').val(opt);
		$('#frm').submit();
	},13000);
}

function exitConf2(opt) {
	webiopi().callMacro("dataUpdate2", [opt,]);
//	webiopi().callMacro("dataUpdate", [point, uid, rid]);
//	if (auto == 1) {
//		swal("AUTOを終了させてください");
//		return false;
//	}
	$('#opt').val(opt);
	$('#frm').submit();
//	window.location.href = url;
}

function exitConf3(url) {
	webiopi().callMacro("dataUpdate", [point, uid, rid]);
//	if (auto == 1) {
//		swal("AUTOを終了させてください");
//		return false;
//	}
	window.location.href = url;
}



function neraiOff() {
//    $('#neraiButton1').css({'background':bg_off,'border-bottom':bb_off,'color':cl_off});
//    $('#neraiButton2').css({'background':bg_off,'border-bottom':bb_off,'color':cl_off});
//    $('#neraiButton3').css({'background':bg_off,'border-bottom':bb_off,'color':cl_off});
}

function btnAutoClick(obj) {
    if (auto == 1) {
        auto = 0;
//        $(obj).css({'background':bg_off,'border-bottom':bb_off,'color':cl_off});
        $(obj).css('background','url(../img/btn-auto-0.png) left top no-repeat');
    } else {
//        $(obj).css({'background':bg_on,'border-bottom':bb_on,'color':cl_on});
        $(obj).css('background','url(../img/btn-auto-1.png) left top no-repeat');
        auto = 1;
    }
}

function btnNerai1Click(obj) {
    if (nerai1 == 1) {
        nerai1 = 0;
        //$(obj).css({'background':bg_off,'border-bottom':bb_off,'color':cl_off});
        $(obj).css('background','url(../img/btn-nerai-0.png) left top no-repeat');
    } else {
        neraiOff();
        //$(obj).css({'background':bg_on,'border-bottom':bb_on,'color':cl_on});
        $(obj).css('background','url(../img/btn-nerai-1.png) left top no-repeat');
        nerai1 = 1;
        nerai2 = 0;
        nerai3 = 0;
    }
}

function btnNerai2Click(obj) {
    if (nerai2 == 1) {
        $(obj).css({'background':bg_off,'border-bottom':bb_off,'color':cl_off});
        nerai2 = 0;
    } else {
        neraiOff();
        $(obj).css({'background':bg_on,'border-bottom':bb_on,'color':cl_on});
        nerai1 = 0;
        nerai2 = 1;
        nerai3 = 0;
    }
}

function btnNerai3Click(obj) {
    if (nerai3 == 1) {
        $(obj).css({'background':bg_off,'border-bottom':bb_off,'color':cl_off});
        nerai3 = 0;
    } else {
        neraiOff();
        $(obj).css({'background':bg_on,'border-bottom':bb_on,'color':cl_on});
        nerai1 = 0;
        nerai2 = 0;
        nerai3 = 1;
    }
}

function getStatus() { webiopi().callMacro("getStatus", 2, callbackGetStatus); }

function callbackGetStatus(macro, args, data) {
//	credit, game, st_ap, st_rb, st_bb, st_ct, auto_count, error_code
    var resArray = data.split(",");
    if (resArray[7] != 0) {
        exitConf(resArray[7]);
    }
//    $("#debug").html(err);
    $("#info").html("POINT : " + resArray[0] + " | GAME : " + resArray[1]);
    point = Number(resArray[0]);
    agct = Number(resArray[6]);
	if (agct > ag_max) {
//		alert('agct=' + agct + ' agmax=' + ag_max);
		exitConf(1);
//	} else {
//		$("#debug").html("AG : " + agct + " auto : " + auto);
	}
    if (resArray[3] == "1") $('#rb_on').css({'visibility':'visible'});
    else $('#rb_on').css({'visibility':'hidden'});
    if (resArray[4] == "1") $('#bb_on').css({'visibility':'visible'});
    else $('#bb_on').css({'visibility':'hidden'});

/*
    if (resArray[3] == "1") {
	    $('#rb_on').css({'display':'block'});
    } else {
	    $('#rb_on').css({'display':'none'});
	}
    if (resArray[4] == "1") {
	    $('#bb_on').css({'display':'block'});
    } else {
	    $('#bb_on').css({'display':'none'});
	}

*/


//    if (resArray[5] == "1") $('#ct_on').css({'visibility':'visible'});
//    else $('#ct_on').css({'visibility':'hidden'});
    if (point > 0) {
        webiopi().callMacro("setActive", 1);
    } else {
        webiopi().callMacro("setActive", 0);
    }
}